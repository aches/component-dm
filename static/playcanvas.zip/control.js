/**
 *
 * @param {changeToWhiteCall:function,changeToBlackCall:function,modelBtnArry:[{title:string,active:boolean,changeModelCall:function}]   } option
 */
var ModelControl = function (option) {

    let isShowCamera = false;

    //let currentIndex = 0;
    //let preIndex = 0;
    let background = "";

    //let modelBackgroundMap = {};
    let modelPosition = {};

    let deviceId;

    //插入css 样式
    var loadCssCode = function (code) {
        var style = document.createElement('style');
        style.type = 'text/css';
        style.rel = 'stylesheet';
        //for Chrome Firefox Opera Safari
        style.appendChild(document.createTextNode(code));
        //for IE
        //style.styleSheet.cssText = code;
        var head = document.getElementsByTagName('head')[0];
        head.appendChild(style);
    };

    //插入html代码
    var loadHtml = function (html) {
        document.body.insertAdjacentHTML('beforeend', html);
    };


    //初始化按钮样式
    var initCss = function () {
        /* 左侧切换背景样式 */
        var leftControlHeight;
        if (isShowCamera == true) {
            leftControlHeight = 186;
        } else {
            leftControlHeight = 124;
            loadCssCode(' .leftControl-div-bgBtn.camera{ display:none;} ');
        }

        loadCssCode(' body{ background: rgba(0, 0, 0, 0.0) !important;}')
        loadCssCode(' .leftControl-div-bgGroup {position: absolute;z-index:99; top: calc(50% - ' + leftControlHeight / 2 + 'px);left:20px;} ');
        loadCssCode(' .leftControl-div-bgBtn { width: 50px; height: 50px; cursor: pointer;  border-radius: 50%; box-shadow: 0 0 3px rgba(0,0,0,.5); margin-top: 12px; } ');
        loadCssCode(' .leftControl-div-bgBtn img{ width: 100%; height: 100%;} ');

        /*  loadCssCode(' .leftControl-div-bgBtn.white { background:rgba(255,255,255,0.3)} ');
         loadCssCode(' .leftControl-div-bgBtn.black { background:rgba(52,52,52,0.4) } '); */

        /* 右侧切换模型按钮 */
        loadCssCode(' .rightControl-div-modelBtnGroup {  position: absolute; right: 0; bottom: 40px; right:20px;z-index:99; } ');
        loadCssCode(' .rightControl-div-modelBtn { font-size: 16px; color: #fff; width: 80px; height: 34px; font-weight: 500; line-height: 33px; text-align: center; background: #a9a9a9; border: 2px solid #c5c5c5;' +
            'border-radius: 6px; cursor: pointer; margin: 12px 0; box-shadow: 0 0 1px rgba(0,0,0,.8); }');

        loadCssCode(' .rightControl-div-modelBtn.active { background: #6a6a6a; }');
        loadCssCode(' canvas { position:absolute ;z-index:10 }');

        loadCssCode('.cameraVideo { width: 100%;height: 100%;object-fit: fill;position:absolute;z-index:0}');

        loadCssCode('.event_disabled { pointer-events: none;cursor: default;opacity: 0.5;}');

        /*横屏提示语*/
        /** 提示用户使用pad或者pc查看 **/
        loadCssCode('.advice_div_tip { position: absolute; top: 16px; width: 416px; height: 48px; background: rgba(250,250,250,0.92);' + 
            ' border: 1px solid rgba(0,0,0,0.06); box-shadow: 0 1px 3px 0 rgba(0,0,0,0.09); border-radius: 100px; font-size: 16px; color: #525252; text-align: center; line-height: 48px;' + 
            ' left: calc( 50% - 208px); transition: opacity 0.3s; opacity: 1; z-index: 10;}');
    };

    //初始化按钮
    var initElement = function () {
        //切换背景按钮
        loadHtml('<div class="leftControl-div-bgGroup">' +
            '<div class="leftControl-div-bgBtn camera" id="cameraBtn"><img src="./tran.png" /></div>' +
            '<div class="leftControl-div-bgBtn white"><img src="./white.png" /></div>' +
            '<div class="leftControl-div-bgBtn black"><img src="./black.png" /></div></div>');

        //切换模型按钮
        var btnHtml = '';
        for (var i = 0; i < option.modelBtnArry.length; i++) {
            var modelBtnObj = option.modelBtnArry[i];
            var active = modelBtnObj.hasOwnProperty('active') && modelBtnObj.active == true ? 'active' : '';
            btnHtml += '<div class="rightControl-div-modelBtn ' + active + '">' + modelBtnObj.title + '</div>';
        }

        loadHtml('<div class="rightControl-div-modelBtnGroup">' + btnHtml + '</div>');
        loadHtml('<video id="cameraVideo" autoplay="" class="cameraVideo" ></video>');

    };

    //移除选中样式
    var removeModelActiveClass = function () {
        var changeModelBtns = document.querySelectorAll('.rightControl-div-modelBtn');
        for (var i = 0; i < changeModelBtns.length; i++) {
            changeModelBtns[i].classList.remove('active');
        }
    }

    //增加模型按钮禁用样式
    var addModelDisabledClass = function () {
        var changeModelBtns = document.querySelectorAll('.rightControl-div-modelBtn');
        for (var i = 0; i < changeModelBtns.length; i++) {
            changeModelBtns[i].classList.add('event_disabled');
        }
    }

    //移除选中样式
    var removeModelDisableClass = function () {
        var changeModelBtns = document.querySelectorAll('.rightControl-div-modelBtn');
        for (var i = 0; i < changeModelBtns.length; i++) {
            changeModelBtns[i].classList.remove('event_disabled');
        }
    }

    //阻止事件冒泡
    var stopEvent = function (element,call) {
        element.addEventListener("click", (event) => {
            call(event);
            event.preventDefault();
            event.stopPropagation();
        });
        element.addEventListener("mouseup", (event) => {
            event.preventDefault();
            event.stopPropagation();
        });
        element.addEventListener("mousedown", (event) => {
            call(event);
            event.preventDefault();
            event.stopPropagation();
        });
        element.addEventListener("touchstart", (event) => {
            call(event);
            event.preventDefault();
            event.stopPropagation();
        });
        element.addEventListener("touchend", (event) => {
            event.preventDefault();
            event.stopPropagation();
        });
    }

    //初始化按钮事件
    var initEvent = function () {
        const showCameraBtn = document.querySelector('.leftControl-div-bgBtn.camera');
        const changeWhiteBtn = document.querySelector('.leftControl-div-bgBtn.white');
        const changeBlackBtn = document.querySelector('.leftControl-div-bgBtn.black');
        const changeModelBtns = document.querySelectorAll('.rightControl-div-modelBtn');

        //绑定切换背景按钮
        // changeWhiteBtn.addEventListener('click', () => {
        //     background = "white";
        //     option.changeToWhiteCall();
        // });
        // changeBlackBtn.addEventListener('click', () => {
        //     background = "black";
        //     option.changeToBlackCall();
        // });

        stopEvent(changeWhiteBtn,(event)=>{
            background = "white";
            option.changeToWhiteCall();
        });
        stopEvent(changeBlackBtn,(event)=>{
            background = "black";
            option.changeToBlackCall();
        });

        //绑定切换模型事件
        for (let i = 0; i < changeModelBtns.length; i++) {
            const modeBtnCall = option.modelBtnArry[i].changeModelCall;
            //changeModelBtns[i].addEventListener("click",option.modelBtnArry[i].changeModelCall,false);
            stopEvent(changeModelBtns[i],(event) => {
                //前一个索引,记录位置
                if(window.orbitCamera){
                    modelPosition = {
                    startDistance: window.orbitCamera.distance,
                    startYaw: window.orbitCamera.yaw,
                    startPitch: window.orbitCamera.pitch,
                    startPivotPosition: window.orbitCamera.pivotPoint.clone()
                    }
                }
                // modelBackgroundMap[i] = background;

                //先禁用点击
                modeBtnCall();
                removeModelActiveClass();
                /*addModelDisabledClass();
                //1.5秒后移除禁用
                setTimeout(()=>{
                    removeModelDisableClass();
                },1500);*/
                event.target.classList.add("active");
                //还原上次背景
                //restoreBackground(i);
            });  

        /*    changeModelBtns[i].addEventListener("click", (event) => {
                //前一个索引,记录位置

                modelPosition = {
                    startDistance: window.orbitCamera.distance,
                    startYaw: window.orbitCamera.yaw,
                    startPitch: window.orbitCamera.pitch,
                    startPivotPosition: window.orbitCamera.pivotPoint.clone()
                }

                // modelBackgroundMap[i] = background;

                //先禁用点击
                modeBtnCall();
                removeModelActiveClass();
                /!*addModelDisabledClass();
                //1.5秒后移除禁用
                setTimeout(()=>{
                    removeModelDisableClass();
                },1500);*!/
                event.target.classList.add("active");
                //还原上次背景
                //restoreBackground(i);
            }, false);*/
        }

        stopEvent(showCameraBtn,() =>{
            background = "camera";
            if(cameraController){
                cameraController.setTransparent();
            }else{
                console.warn('cameraController not exist , setTransparent faild');
            }
            //getUserMediaCamera();
        });
        //调用摄像头
        /*showCameraBtn.addEventListener('click', function () {
            getUserMediaCamera();
        });*/
    };

   // 当用户第一次横屏时显示提示信息
    var showAdvice = function() {
        const adviceEle = document.getElementById('browserAdvice');
        if ( adviceEle ) {
            return;
        }

        const adviceDiv = document.createElement('div');
        adviceDiv.classList.add('advice_div_tip');
        adviceDiv.id = 'browserAdvice';
        adviceDiv.innerHTML = '建议您在电脑或平板上打开，以获取最佳的演示效果';
        document.body.appendChild(adviceDiv);
        setTimeout(() => {
            adviceDiv.style.opacity = '0';

        }, 3000);
    }

    var initTip = function(){
        if(window.screen.width < 500 || window.screen.height < 500){
    showAdvice();
        }
        
    }


    //还原背景
    var restoreBackground = function (index) {
        if (!background) {
            background = location.hash.indexOf("camera=true") > -1 ? "camera" : "white";
        }
        if (background == "camera") {
            cameraController.setTransparent();
        } else if (background == "black") {
            option.changeToBlackCall();
        } else if (background == "white") {
            option.changeToWhiteCall();
        }
        if (modelPosition) {

            window.orbitCamera.distance = modelPosition.startDistance;
            window.orbitCamera.yaw = modelPosition.startYaw;
            window.orbitCamera.pitch = modelPosition.startPitch;
            window.orbitCamera.pivotPoint = modelPosition.startPivotPosition;
        }
    }

    //模型切换事件
    var modelChangeEvent = function (scenceId) {
        if(window.scenceId == scenceId){
            return;
        }
        window.scenceId = scenceId;
        sceneController.changeScene(scenceId,()=>{
            this.restoreBackground();
        });
    }


    //处理playcanvas 内置的一些事件
    var handlePlaycanvas = function () {
        pc.MOUSEBUTTON_RIGHT = null
    }


    /* 调用摄像机方法 */

    var constraints = {
        audio: false,
        video: true
    };


    var getUserMediaCamera = function () {
        background = "camera";
        //cameraController.setTransparent();
        //如果后置摄像头存在，则采用后置摄像头
        if (deviceId) {
            constraints.video = {deviceId: {exact: deviceId}};
        }else{
            constraints.video = false;
        }
        navigator.mediaDevices.getUserMedia(constraints).then(handleSuccess).catch(handleError);
    }

    var handleSuccess = function (stream) {
        window.stream = stream;
        document.getElementById("cameraVideo").srcObject = stream;
    }

    var handleError = function (error) {
        //console.error('navigator.getUserMedia error: ', error);
        console.warn('找不到视频输入设备');
    }

    var initCamera = function () {

        if (!window.hasOwnProperty("cameraController")) {
            requestAnimationFrame(initCamera)
        } else {
            //getUserMediaCamera();
            cameraController.setTransparent();
        }
    }
    var initBackground = function() {
        if (!window.hasOwnProperty("cameraController")) {
            requestAnimationFrame(initBackground);
        } else {
            option.changeToWhiteCall();
        }
    }


    var showCameraBtn = function () {
        document.getElementById("cameraBtn").style.display = "block";
    };
    var hideCameraBtn = function () {
        document.getElementById("cameraBtn").style.display = "none";
    }

    var init = function () {
        if (location.hash.indexOf("camera=true") > -1) {
            isShowCamera = true;
            let index = 0;

            if(navigator.mediaDevices === undefined){
                console.log('WebRTC issue-!navigator.mediaDevices not present in your browser');
            }else{
                if(navigator.mediaDevices.enumerateDevices() === undefined){
                    navigator.mediaDevices.getUserMedia().then((deviceInfos) => {

                    for (let i = 0; i < deviceInfos.length; i++) {
                        const deviceInfo = deviceInfos[i];
                        //console.log(deviceInfo.kind)
                        //screen-capture-recorder
                        if (deviceInfo.kind != 'videoinput' || (deviceInfo.label && deviceInfo.label.indexOf('capture') >-1 )) {
                            //console.log("continue")
                            continue;
                        }

                        //console.log(i + "--" + deviceInfo.kind + "--" + 'kind' in deviceInfo);
                        //console.log (deviceInfo)
                        index++;
                        deviceId = deviceInfo.deviceId;
                        if (deviceInfo.label.indexOf('back') >= 0 || index == 2) {
                            deviceId = deviceInfo.deviceId;

                        }
                    }
                        initCamera();
                        getUserMediaCamera();
                    }).catch(handleError);  
                }else{
                    navigator.mediaDevices.enumerateDevices().then((deviceInfos) => {

                    for (let i = 0; i < deviceInfos.length; i++) {
                        const deviceInfo = deviceInfos[i];
                        //console.log(deviceInfo.kind)
                        //screen-capture-recorder
                        if (deviceInfo.kind != 'videoinput' || (deviceInfo.label && deviceInfo.label.indexOf('capture') >-1 )) {
                            //console.log("continue")
                            continue;
                        }

                        //console.log(i + "--" + deviceInfo.kind + "--" + 'kind' in deviceInfo);
                        //console.log (deviceInfo)
                        index++;
                        deviceId = deviceInfo.deviceId;
                        if (deviceInfo.label.indexOf('back') >= 0 || index == 2) {
                            deviceId = deviceInfo.deviceId;

                        }
                    }
                        initCamera();
                        getUserMediaCamera();
                    }).catch(handleError);  
                }
            }
        }
        initCss();
        initElement();
        initEvent();
        initBackground();
        handlePlaycanvas();
        initTip();
    };

    init();

    return {
        showCameraBtn: showCameraBtn,
        hideCameraBtn: hideCameraBtn,
        restoreBackground: restoreBackground,
        modelChangeEvent,modelChangeEvent,
        getModelMap: () => {
            return modelPosition;
        }
    };
};





/*    let mode;
	      	var modelOption = {
				//点击白色背景色按钮
			    changeToWhiteCall:function(){
			         cameraController.changeClearColor('white',1);
			    },
				//点击黑色背景色按钮
			    changeToBlackCall:function(){
			         cameraController.changeClearColor('black',1);
			    },
		    	modelBtnArry:[
		    		{ title:'球棍模型', active:true, changeModelCall:function(){
		    				var scenceId = 608387;
		    				mode.modelChangeEvent(scenceId);
			            }
			        },
			        { title:'比例模型', changeModelCall:function(){
			        		var scenceId = 608386;
			        		mode.modelChangeEvent(scenceId);
			            }
			        }
			    ]
			}
		  mode = new ModelControl(modelOption);
		  window.scenceId = 608387; */


